using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using System.IO;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;

public class ResourceManager : Singleton<ResourceManager>
{
    public string PersistentDataPath = Application.persistentDataPath;
    public string StreamingAssetsPath = Application.streamingAssetsPath;
    public static string jsonPath = "Assets/StreamingAssets/Json/";
    public string bytePath = Application.streamingAssetsPath + "/Byte/";
    public string prefabsPath = "Assets/BundleResources/Prefabs/";
    public string assetBundlePath = "Assets/AssetBundles/";
    public string assetBundleManifestPath = "Assets/AssetBundles/";

    private Dictionary<string, AssetBundle> allAssetBundleDict = new Dictionary<string, AssetBundle>();

#if UNITY_EDITOR

#endif
    public async Task<GameObject> LoadAsset(string assetName)
    {
        return await Addressables.LoadAssetAsync<GameObject>(assetName).Task;
    }
    public void UnLoadAsset(string assetName)
    {
        Addressables.Release(assetName);
    }
    public AssetBundle LoadAssetBundle(string assetBundleName)
    {
        //string[] depend = AssetBundleManifest.GetAllDependencies(assetBundleName);
        if (!File.Exists(assetBundlePath + assetBundleName))
        {
            Debug.LogWarning("路径不存在" + assetBundleName);
            return null;
        }
        if (allAssetBundleDict.TryGetValue(assetBundleName, out AssetBundle assetBundle))
        {
            Debug.Log(assetBundleName + " 该路径ab包已加载" + assetBundle);
            return assetBundle;
        }
        //if (Directory.Exists(AssetBundlePath + assetBundleName))
        {
            assetBundle = AssetBundle.LoadFromFile(assetBundlePath + assetBundleName);
            allAssetBundleDict[assetBundleName] = assetBundle;
            //Debug.Log(assetBundleName + " " + assetBundle);
        }
        //Debug.Log(assetBundleName + "该路径不存在 ");
        return assetBundle;
    }
    public async Task<AssetBundle> LoadAssetBundleAsync(string assetBundleName)
    {
        AssetBundle assetBundle = await Task.Run(() =>
        {
            AssetBundle bundle = AssetBundle.LoadFromFile(assetBundlePath + assetBundleName);
            return bundle;
        });
        if (assetBundle != null)
        {
            allAssetBundleDict[assetBundleName] = assetBundle;
        }
        return assetBundle;
    }
    public void UnloadAssetBundle(string assetBundleName)
    {

        if (allAssetBundleDict.TryGetValue(assetBundleName, out AssetBundle assetBundle))
        {
            assetBundle.Unload(true);
            allAssetBundleDict.Remove(assetBundleName);
        }
    }
    public T LoadFromJson<T>(string jsonName) where T : class
    {
        T data = null;
        //if (File.Exists(jsonName))
        {
            using (StreamReader reader = new StreamReader(jsonPath + jsonName + ".json"))
            {
                string json = reader.ReadToEnd();
                //data = JsonConvert.DeserializeObject<T>(json);
                //data = JsonSerializer.Deserialize<T>(json);
                data = JsonUtility.FromJson<T>(json);
            }
        }
        return data;
    }
    public T LoadFromBinary<T>(string byteName) where T : class
    {
        T data = null;

        //if (File.Exists(bytePath + byteName))
        {
            Debug.Log("-----------");
            using (FileStream stream = new FileStream(bytePath + byteName + ".byte", FileMode.Open))
            {
                BinaryFormatter formatter = new BinaryFormatter();
                Debug.Log(stream.Name + "  ========= " + formatter.Context);
                Debug.Log("87 =============" + formatter.Deserialize(stream));
                data = formatter.Deserialize(stream) as T;
            }
        }
        return data;
    }
}
