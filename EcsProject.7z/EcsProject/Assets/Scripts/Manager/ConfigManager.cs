using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConfigManager : Singleton<ConfigManager>
{
    // private Dictionary<string, ConfigBase> configDict = new Dictionary<string, ConfigBase>();
    // public void LoadConfig<T>(string configName) where T : ConfigBase
    // {
    //     //T t = ResourceManager.Instance.LoadFromBinary<T>(configName);
    //     T t = ResourceManager.Instance.LoadFromJson<T>(configName);
    //     Debug.Log("  T  " + t);
    //     if (t != null)
    //     {
    //         configDict[configName] = t;
    //     }
    // }

    // public T GetConfig<T>(string configName) where T : ConfigBase
    // {
    //     if (configDict.ContainsKey(configName))
    //     {
    //         return (T)configDict[configName];
    //     }
    //     else
    //     {
    //         Debug.LogError("Failed to find config: " + configName);
    //         return null;
    //     }
    // }

    // public void LoadScriptableObjectConfig<T>(string configName) where T : ExcelItemBase
    // {

    // }
}
