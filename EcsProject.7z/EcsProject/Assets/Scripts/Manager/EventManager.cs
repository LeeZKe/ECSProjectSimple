using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum EventType
{
    Button,
}
public class EventManager : Singleton<EventManager>
{
    /// <summary>
    /// 
    /// </summary>

    public delegate void EventDelegate();
    public delegate void EventDelegate<T>(T t);
    public delegate void EventDelegate<T, U>(T t, U u);
    public delegate void EventDelegate<T, U, V>(T t, U u, V v);
    private Dictionary<string, Delegate> eventListeners = new Dictionary<string, Delegate>();
    public void RegisterEvent(string eventName, EventDelegate handler)
    {
        if (!eventListeners.ContainsKey(eventName))
        {
            eventListeners[eventName] = handler;
        }
    }
    public void RegisterEvent<T>(string eventName, EventDelegate<T> handler)
    {
        if (!eventListeners.ContainsKey(eventName))
        {
            eventListeners[eventName] = handler;
        }
    }
    public void RegisterEvent<T, U>(string eventName, EventDelegate<T, U> handler)
    {
        if (!eventListeners.ContainsKey(eventName))
        {
            eventListeners[eventName] = handler;
        }
    }
    public void RegisterEvent<T, U, V>(string eventName, EventDelegate<T, U, V> handler)
    {
        if (!eventListeners.ContainsKey(eventName))
        {
            eventListeners[eventName] = handler;
        }
    }

    public void RemoveEvent(string eventName)
    {
        if (eventListeners.ContainsKey(eventName))
        {
            eventListeners.Remove(eventName);
        }

    }
    public void RemoveEvent<T>(string eventName)
    {
        if (eventListeners.ContainsKey(eventName))
        {
            eventListeners.Remove(eventName);
        }

    }
    public void RemoveEvent<T, U>(string eventName)
    {
        if (eventListeners.ContainsKey(eventName))
        {
            eventListeners.Remove(eventName);
        }

    }
    public void RemoveEvent<T, U, V>(string eventName)
    {
        if (eventListeners.ContainsKey(eventName))
        {
            eventListeners.Remove(eventName);
        }

    }

    public void DispatchEvent(string eventName)
    {
        if (eventListeners.TryGetValue(eventName, out Delegate handler))
        {
            ((EventDelegate)handler)();
        }
    }
    public void DispatchEvent<T>(string eventName, T t)
    {
        if (eventListeners.TryGetValue(eventName, out Delegate handler))
        {
            ((EventDelegate<T>)handler)(t);
        }
    }
    public void DispatchEvent<T, U>(string eventName, T t, U u)
    {
        if (eventListeners.TryGetValue(eventName, out Delegate handler))
        {
            ((EventDelegate<T, U>)handler)(t, u);
        }
    }
    public void DispatchEvent<T, U, V>(string eventName, T t, U u, V v)
    {
        if (eventListeners.TryGetValue(eventName, out Delegate handler))
        {
            ((EventDelegate<T, U, V>)handler)(t, u, v);
        }
    }
}
