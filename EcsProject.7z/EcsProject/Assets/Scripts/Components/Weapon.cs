using Unity.Entities;


public struct Weapon : IComponentData
{
    public float atk;
    public float intervalTime;
    public Entity weaponEntity;
    public Entity targetEntity;
}

