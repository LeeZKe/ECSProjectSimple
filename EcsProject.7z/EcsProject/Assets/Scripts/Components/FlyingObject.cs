using Unity.Entities;


public struct FlyingObject : IComponentData
{
    public float flySpeed;
    public float lifeTime;
    public Entity targetEntity;
}
