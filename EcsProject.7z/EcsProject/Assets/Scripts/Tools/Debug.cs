using System.Diagnostics;

public static class Debug
{
    private static Stopwatch timer = new Stopwatch();
    public static void Log(object message)
    {
#if UNITY_EDITOR
        UnityEngine.Debug.Log(message + "\n" + UnityEngine.StackTraceUtility.ExtractStackTrace());
#endif
    }
    public static void LogWithTime(string message)
    {
#if UNITY_EDITOR
        timer.Start();
        Log(message);
        timer.Stop();
        Log("Execution time: " + timer.ElapsedMilliseconds + "ms");
        timer.Reset();
#endif
    }
    public static void LogWarning(object message)
    {
#if UNITY_EDITOR
        UnityEngine.Debug.LogWarning(message);
#endif
    }

    public static void LogError(object message)
    {
#if UNITY_EDITOR
        UnityEngine.Debug.LogWarning(message);
#endif
    }

}
