using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;
using Unity.Burst;

//[UpdateInGroup(typeof(InitializationSystemGroup))]
public partial struct WeaponSystem : ISystem
{
    public bool isCompile;
    //[BurstCompile]
    public void OnCreate(ref SystemState state)
    {
        isCompile = false;
        //state.RequireForUpdate<Weapon>();
    }
    //[BurstCompile]
    public void OnUpdate(ref SystemState state)
    {

        var ecbSingleton = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>();
        var ecb = ecbSingleton.CreateCommandBuffer(state.WorldUnmanaged);
        GameObject obj = Test.Instance.weaponObj;
        if (obj != null && !isCompile)
        {
            isCompile = true;
            var go = GameObject.Instantiate(obj);
            Entity entity = state.EntityManager.CreateEntity();
            // foreach (var (enemyEntity, e) in SystemAPI.Query<EnemyEntity>().WithEntityAccess())
            // {
            //     entity = e;
            // }
            ecb.AddComponent(entity, new EnemyGO(go));
        }
    }
}
