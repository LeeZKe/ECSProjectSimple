using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;
using Unity.Transforms;
using Unity.Physics;
using Unity.Mathematics;

public partial class PlayerMovementSystem : SystemBase
{
    public InputSystem inputActions;
    protected override void OnCreate()
    {
        inputActions = new InputSystem();
        inputActions.Enable();

    }
    protected override void OnUpdate()
    {
        Vector2 input = inputActions.Move.WASD.ReadValue<Vector2>();
        float2 PlayerPos = new float2(0, 0);
        Entities
        .WithAll<PlayerEntity>()
        .ForEach((ref LocalTransform transform, ref PhysicsVelocity vel, ref PlayerEntity playerEntity) =>
        {
            if (input.x != 0)
            {
                PlayerPos += transform.Right().xz * input.x * playerEntity.speed;
            }
            if (input.y != 0)
            {
                PlayerPos += transform.Forward().xz * input.y * playerEntity.speed;
            }
            vel.Linear.xz = PlayerPos;
        })
        //.Run();
        .WithBurst().ScheduleParallel();
    }
}
