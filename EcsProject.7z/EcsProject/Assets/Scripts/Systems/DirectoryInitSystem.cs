using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;
public partial struct DirectoryInitSystem : ISystem
{
    public void OnCreate(ref SystemState state)
    {
        // We need to wait for the scene to load before Updating, so we must RequireForUpdate at
        // least one component type loaded from the s
        state.RequireForUpdate<EntityPrefabComponent>();
    }

    public void OnUpdate(ref SystemState state)
    {
        state.Enabled = false;
        Debug.Log("onUpdate");
        // if (Test.Instance.obj != null)
        // {
        //     Debug.Log(Test.Instance.obj);
        //     //var go = GameObject.Instantiate(Test.Instance.obj);
        //     var go = Test.Instance.obj;
        //     Debug.Log(go);
        //     var entity = state.EntityManager.CreateEntity();
        //     state.EntityManager.AddComponentData(entity, new RotatorGO(go));
        // }

    }
}

public class RotatorGO : IComponentData
{
    public GameObject Value;

    public RotatorGO(GameObject value)
    {
        Value = value;
    }

    // Every IComponentData class must have a no-arg constructor.
    public RotatorGO()
    {
    }
}
