using Unity.Entities;
using Unity.Transforms;
using Unity.Physics;
using Unity.Mathematics;
using System.Numerics;
using UnityEngine;
using Unity.Burst;


[BurstCompile]
partial struct EnemyMoveJob : IJobEntity
{
    public LocalTransform playerTransform;
    void Execute(ref LocalTransform transform, ref EnemyEntity enemy)
    {

        float3 dis = playerTransform.Position - transform.Position;
        float3 normalDis = math.normalize(dis);
        if (enemy.enemyState == EnemyState.Chase)
        {
            if (math.distance(playerTransform.Position, transform.Position) < enemy.attackRange)
            {
                //enemy.enemyState = EnemyState.Attack;
            }
            else
            {
                transform.Position += normalDis * enemy.speed;
            }
        }
        else if (enemy.enemyState == EnemyState.Attack)
        {
            if (math.distance(playerTransform.Position, transform.Position) > enemy.attackRange)
            {
                //enemy.enemyState = EnemyState.Chase;
            }
        }
    }
}
[BurstCompile]
public partial struct EnemySystem : ISystem
{
    [BurstCompile]
    public void OnCreate(ref SystemState state)
    {
    }
    [BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
        Entity playerEntity = SystemAPI.GetSingletonEntity<PlayerEntity>();
        LocalTransform _playerTransform = SystemAPI.GetComponent<LocalTransform>(playerEntity);
        var jab = new EnemyMoveJob { playerTransform = _playerTransform };
        jab.ScheduleParallel();
        // foreach (var (enemy, transform, entity) in SystemAPI.Query<RefRW<EnemyEntity>, RefRW<LocalTransform>>().WithEntityAccess())
        // {
        //     //Debug.Log(entity.Index);
        //     float3 dis = _playerTransform.Position - transform.ValueRW.Position;
        //     float3 normalDis = math.normalize(dis);
        //     if (enemy.ValueRW.enemyState == EnemyState.Chase)
        //     {
        //         if (math.distance(_playerTransform.Position, transform.ValueRW.Position) < enemy.ValueRW.attackRange)
        //         {
        //             enemy.ValueRW.enemyState = EnemyState.Attack;
        //             //enemy.ValueRW.targetEntity = playEntity;
        //         }
        //         else
        //         {
        //             transform.ValueRW.Position += normalDis * enemy.ValueRW.speed;
        //         }
        //     }
        //     else if (enemy.ValueRW.enemyState == EnemyState.Attack)
        //     {
        //         if (math.distance(_playerTransform.Position, transform.ValueRW.Position) > enemy.ValueRW.attackRange)
        //         {
        //             enemy.ValueRW.enemyState = EnemyState.Chase;
        //         }
        //     }
        // }
    }

    // private EntityCommandBuffer.ParallelWriter GetEntityCommandBuffer(ref SystemState state)
    // {
    //     var ecbSingleton = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>();
    //     var ecb = ecbSingleton.CreateCommandBuffer(state.WorldUnmanaged);
    //     return ecb.AsParallelWriter();
    // }
}
