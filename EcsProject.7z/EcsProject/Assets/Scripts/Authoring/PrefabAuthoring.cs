using Unity.Entities;
using UnityEngine;

public class Prefab : IComponentData
{
    public GameObject obj;
}


