using Unity.Entities;
using Unity.Scenes;
using UnityEngine;
public struct EntityPrefabComponent : IComponentData
{
    public Entity Value;
}

public class GetPrefabAuthoring : MonoBehaviour
{
    public GameObject Prefab;
}

public class GetPrefabBaker : Baker<GetPrefabAuthoring>
{
    public override void Bake(GetPrefabAuthoring authoring)
    {
        //Debug.Log(" authoring.Prefab " + authoring.Prefab);
        // Register the Prefab in the Baker
        var entityPrefab = GetEntity(authoring.Prefab, TransformUsageFlags.Dynamic);
        //Debug.Log(entityPrefab);
        // Add the Entity reference to a component for instantiation later
        var entity = GetEntity(TransformUsageFlags.None);
        //Debug.Log(entity);
        AddComponent(entity, new EntityPrefabComponent() { Value = entityPrefab });
    }
}