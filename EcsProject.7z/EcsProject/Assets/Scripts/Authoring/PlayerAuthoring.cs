using Unity.Entities;

struct PlayerEntity : IComponentData
{
    public float speed;
}
class PlayerAuthoring : UnityEngine.MonoBehaviour
{
    public float speed;
}
class PlayerBacker : Baker<PlayerAuthoring>
{
    public override void Bake(PlayerAuthoring authoring)
    {
        Entity entity = GetEntity(authoring, TransformUsageFlags.NonUniformScale | TransformUsageFlags.Dynamic);
        AddComponent(entity, new PlayerEntity
        {
            speed = authoring.speed,
        });
    }
}
