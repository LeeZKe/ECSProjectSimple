using Unity.Entities;
enum EnemyState
{
    Patrol,
    Attack,
    Chase,
}
struct EnemyEntity : IComponentData
{
    public float speed;
    //public Entity targetEntity;
    public EnemyState enemyState;
    public float attackRange;
}
public class EnemyAuthoring : UnityEngine.MonoBehaviour
{
    public float speed;
}
class EnemyBacker : Baker<EnemyAuthoring>
{
    public override void Bake(EnemyAuthoring authoring)
    {
        //Debug.Log("Enemy baking");
        Entity entity = GetEntity(authoring, TransformUsageFlags.NonUniformScale | TransformUsageFlags.Dynamic);

        AddComponent(entity, new EnemyEntity
        {
            speed = authoring.speed,
            enemyState = EnemyState.Chase,
            attackRange = 3,
        });
        //Debug.Log("Enemy baking entity" + entity);
    }

}