using UnityEngine;

public class Test : MonoBehaviourSingleton<Test>
{
    public GameObject obj;
    public GameObject weaponObj;
    private async void Start()
    {
        //obj = await ResourceManager.Instance.LoadAsset("Cube");
        weaponObj = await ResourceManager.Instance.LoadAsset("Weapon");
    }
}

