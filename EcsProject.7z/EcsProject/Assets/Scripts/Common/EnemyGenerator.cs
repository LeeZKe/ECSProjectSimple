using Unity.Entities;
using Unity.Burst;
using Unity.Transforms;
using Unity.Mathematics;
using Unity.Scenes;

[BurstCompile]
public partial struct EnemyGenerator : IJobEntity
{
    public EntityCommandBuffer.ParallelWriter Ecb;
    public Entity enemyPrefab;
    public int spwanCount;
    [BurstCompile]
    public void Execute([ChunkIndexInQuery] int chunkIndex)
    {
        var random = new Random();
        random.InitState();
        // EnemySpawner(chunkIndex, random.NextFloat3());
        for (int i = 0; i < spwanCount; i++)
        {
            EnemySpawner(chunkIndex, random.NextFloat3(new float3(-100, 0, -100), new float3(100, 0, 100)));
        }
    }

    [BurstCompile]
    public void EnemySpawner(int index, float3 enemyPos)
    {
        var e = Ecb.Instantiate(index, enemyPrefab);
        //Debug.Log(index + "  " + e);
        Ecb.SetComponent(index, e, new LocalTransform { Position = enemyPos, Scale = 1 });
        Ecb.SetComponent(index, e, new EnemyEntity { speed = 0.86f, attackRange = 3, enemyState = EnemyState.Chase });
        //Ecb.SetComponent(index, e, new Weapon { atk = 10, intervalTime = 1 });
    }
}

[BurstCompile]
public partial struct EnemySpawningSystem : ISystem
{
    [BurstCompile]
    public void OnCreate(ref SystemState state)
    {
        var query = SystemAPI.QueryBuilder()
            .WithAll<EntityPrefabComponent>()
            .WithNone<PrefabLoadResult>().Build();
        state.EntityManager.AddComponent<RequestEntityPrefabLoaded>(query);

    }
    [BurstCompile]
    public void OnDestory(ref SystemState state) { }
    [BurstCompile]
    public void OnUpdate(ref SystemState state)
    {

        EntityCommandBuffer.ParallelWriter ecb = GetEntityCommandBuffer(ref state);
        Entity entity = Entity.Null;
        foreach (var (EnemyEntity, EntityPrefabComponent) in SystemAPI.Query<EnemyEntity, EntityPrefabComponent>())
        {
            entity = EntityPrefabComponent.Value;
        }
        if (entity != Entity.Null)
        {
            EnemyGenerator enemyGenerator = new EnemyGenerator
            {
                Ecb = ecb,
                enemyPrefab = entity,
                spwanCount = 10,
            };
            enemyGenerator.ScheduleParallel();
        }

        state.Enabled = false;
    }
    private EntityCommandBuffer.ParallelWriter GetEntityCommandBuffer(ref SystemState state)
    {
        var ecbSingleton = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>();
        var ecb = ecbSingleton.CreateCommandBuffer(state.WorldUnmanaged);
        return ecb.AsParallelWriter();
    }
}
